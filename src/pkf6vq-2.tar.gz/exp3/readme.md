The first way to implement the handler is shown in In `entry.S` line 253 `sync_invalid_el1_64:`

The second way is shown in line 255 `sync_invalid_el1_64_:`

By default, `sync_invalid_el1_64` will be used.
